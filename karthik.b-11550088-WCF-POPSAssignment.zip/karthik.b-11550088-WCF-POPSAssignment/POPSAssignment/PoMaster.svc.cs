﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace POPSAssignment
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "PoMaster" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select PoMaster.svc or PoMaster.svc.cs at the Solution Explorer and start debugging.
    public class PoMaster : IPoMaster
    {
        PODbEntities context = new PODbEntities();
        POMASTER pOMASTER = new POMASTER();
        public void AddPOMASTER(POMASTER pOMASTER)
        {
            context.POMASTERs.Add(pOMASTER);
            context.SaveChanges();
        }
        public void DeletePOMASTER(string PoNo)
        {
            var data = context.POMASTERs.Find(PoNo);
            context.POMASTERs.Remove(data);
            context.SaveChanges();
        }
        public POMASTER GetPOMASTER(string PoNo)
        {
            var data = context.POMASTERs.Find(PoNo);
            return data;
        }
        public List<POMASTER> GetPOMASTERs()
        {
            var data = from n in context.POMASTERs select n;
            return data.ToList();
        }
        public void UpdatePOMASTER(POMASTER pOMASTER)
        {
            var data = context.POMASTERs.Find(pOMASTER.PONO);
            data.PODATE = pOMASTER.PODATE;
            context.SaveChanges();
        }
    }
}
