﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace POPSAssignment
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "ISupplierService" in both code and config file together.
    [ServiceContract]
    public interface ISupplierService
    {
        [OperationContract]
        List<SUPPLIER> GetSUPPLIERs();
        [OperationContract]
        SUPPLIER GetSUPPLIER(string suplno);
        [OperationContract]
        void AddSUPPLIER(SUPPLIER supplier);
        [OperationContract]
        void DeleteSUPPLIER(string suplno);
        [OperationContract]
        void UpdateSUPPLIER(SUPPLIER supplier);

    }
}
