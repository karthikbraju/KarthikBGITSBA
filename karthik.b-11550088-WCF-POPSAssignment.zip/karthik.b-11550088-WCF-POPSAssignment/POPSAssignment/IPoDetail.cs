﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace POPSAssignment
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IPoDetail" in both code and config file together.
    [ServiceContract]
    public interface IPoDetail
    {
        [OperationContract]
        List<PODETAIL> GetPoDetails();
        [OperationContract]
        PODETAIL GetPODETAIL(string PoNo,string ItCode);
        [OperationContract]
        void AddPODETAIL(PODETAIL pODETAIL);
        [OperationContract]
        void DeletePODETAIL(string PoNo, string ItCode);
        [OperationContract]
        void UpdatePODETAIL(PODETAIL pODETAIL);
    }
}
