﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace POPSAssignment
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "ItemService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select ItemService.svc or ItemService.svc.cs at the Solution Explorer and start debugging.
    public class ItemService : IItemService
    {
        PODbEntities context = new PODbEntities();
        ITEM item = new ITEM();
        public void AddITEM(ITEM iTEM)
        {
            context.ITEMs.Add(iTEM);
            context.SaveChanges();
        }
        public void DeleteITEM(string Itcode)
        {
            var data = context.ITEMs.Find(Itcode);
            context.ITEMs.Remove(data);
            context.SaveChanges();
        }
        public ITEM GetITEM(string Itcode)
        {
            var data = context.ITEMs.Find(Itcode);
            return data;
        }
        public List<ITEM> GetITEMs()
        {
            var data = from n in context.ITEMs select n;
            return data.ToList();
        }
        public void UpdateITEM(ITEM iTEM)
        {
            var data = context.ITEMs.Find(item.ITCODE);
            data.ITDESC = item.ITDESC;
            data.ITRATE = item.ITRATE;
            context.SaveChanges();
        }
    }
}
