﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace POPSAssignment
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "PoDetail" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select PoDetail.svc or PoDetail.svc.cs at the Solution Explorer and start debugging.
    public class PoDetail : IPoDetail
    {
        PODbEntities context = new PODbEntities();
        PODETAIL pODETAIL = new PODETAIL();
        public void AddPODETAIL(PODETAIL pODETAIL)
        {
            context.PODETAILs.Add(pODETAIL);
            context.SaveChanges();
        }
        public void DeletePODETAIL(string PoNo, string ItCode)
        {
            var data = context.PODETAILs.Find(PoNo);
            context.PODETAILs.Remove(data);
            context.SaveChanges();
        }
        public PODETAIL GetPODETAIL(string PoNo, string ItCode)
        {
            var data = context.PODETAILs.Find(PoNo,ItCode);
            return data;
        }
        public List<PODETAIL> GetPoDetails()
        {
            var data = from n in context.PODETAILs select n;
            return data.ToList();
        }
        public void UpdatePODETAIL(PODETAIL pODETAIL)
        {
            var data = context.PODETAILs.Find(pODETAIL.PONO);
            data.QTY = pODETAIL.QTY;
            context.SaveChanges();
        }
    }
}
