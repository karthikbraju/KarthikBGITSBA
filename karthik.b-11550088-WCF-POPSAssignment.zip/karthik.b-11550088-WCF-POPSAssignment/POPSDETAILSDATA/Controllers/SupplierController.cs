﻿using POPSDETAILSDATA.ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace POPSDETAILSDATA.Controllers
{
    public class SupplierController : Controller
    {
        ServiceReference1.SupplierServiceClient SupplierServiceClient = new ServiceReference1.SupplierServiceClient();
        SUPPLIER supplier = new SUPPLIER();
        // GET: Supplier
        public ActionResult Index()
        {
            var data = SupplierServiceClient.GetSUPPLIERs();
            return View(data);
        }
        [HttpGet]
        public ViewResult AddSupplier()
        { 
            return View();
        }
        [HttpPost]
        public ActionResult AddSupplier(SUPPLIER sUPPLIER)
        {
            SupplierServiceClient.AddSUPPLIER(sUPPLIER);
            return RedirectToAction("Index");
        }
        [HttpGet]
        public ViewResult UpdateSupplier(string id3)
        {
            var data = SupplierServiceClient.GetSUPPLIER(id3);
            return View(data);
        }
        [HttpPost]
        public ActionResult UpdateSupplier(SUPPLIER sUPPLIER)
        {
            SupplierServiceClient.UpdateSUPPLIER(sUPPLIER);
            return RedirectToAction("Index");
        }
        [HttpGet]
        public ViewResult DeleteSupplier(string id2)
        {
            var data = SupplierServiceClient.GetSUPPLIER(id2);
            return View(data);
        }
        [HttpPost]
        public ActionResult DeleteSupplier(string id2,SUPPLIER sUPPLIER)
        {
             SupplierServiceClient.DeleteSUPPLIER(id2);
            return RedirectToAction("Index");
        }
        [HttpGet]
        public ViewResult GetSupplier(string id1)
        {
            var data = SupplierServiceClient.GetSUPPLIER(id1);
            return View(data);
        }
        
       
    }
}