﻿using POPSDETAILSDATA.ServiceReference2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace POPSDETAILSDATA.Controllers
{
    public class ItemsController : Controller
    {
        ServiceReference2.ItemServiceClient ItemServiceClient = new ServiceReference2.ItemServiceClient();
        ITEM item = new ITEM();
        // GET: Items
        public ActionResult Index()
        {
            var data = ItemServiceClient.GetITEMs();
            return View(data);
        }
        [HttpGet]
        public ViewResult AddItem()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddItem(ITEM iTEM)
        {
            ItemServiceClient.AddITEM(iTEM);
            return RedirectToAction("Index");
        }
        [HttpGet]
        public ViewResult UpdateItem(string id3)
        {
            var data = ItemServiceClient.GetITEM(id3);
            return View(data);
        }
        [HttpPost]
        public ActionResult UpdateItem(ITEM iTEM)
        {
            ItemServiceClient.UpdateITEM(iTEM);
            return RedirectToAction("Index");
        }
        [HttpGet]
        public ViewResult DeleteItem(string id2)
        {
            var data = ItemServiceClient.GetITEM(id2);
            return View(data);
        }
        [HttpPost]
        public ActionResult DeleteItem(string id2, ITEM iTEM)
        {
            ItemServiceClient.DeleteITEM(id2);
            return RedirectToAction("Index");
        }
    }
}